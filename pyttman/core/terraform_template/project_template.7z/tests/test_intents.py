import unittest
import pyttman


# Develop unittests for your intents here

class TestSomeIntent(unittest.TestCase):
    pass
