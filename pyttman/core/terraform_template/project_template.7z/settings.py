
# Use these settings to configure Pyttman for your app.
# LOG_FILE_DIR is set up for you when creating new projects. You can
# set this path to whatever you want as long as it is exists.
import os
from pathlib import Path

CHOSEN_LANGUAGE = "en-us"

"""
Create a new file for each time your 
app starts, or append the most recent one.
"""
APPEND_LOG_FILES = True

"""
You can define default response phrases here.
They are randomly selected and will be returned
whenever a command is entered which does not match
any of the loaded features. A 404, of sorts.
"""
DEFAULT_RESPONSES = {
    "en-us": {
        "NoResponse": [
            "Not sure about that one",
            "I was not expecting anything less",
            "I have no clue",
            "Your guess is as good as mine!",
            "No idea about that one",
            "I'm sorry, I don't know what you mean"
        ]
    },
    "sv-se": {
        "NoResponse": [
            "Jag har inget bra svar på det faktiskt",
            "Ingen aning!",
            "Hmm... hänger inte riktigt med där",
            "Ursäkta, jag uppfattade inte?"
        ]
    }
}

"""
This is where you put your Feature objects, for them to be 
loaded with Pyttman and usable in your app.
"""
FEATURES = []  # Example: FEATURES = [ThisFeature(), ThatFeature()]


"""
These variables are used internally by Pyttman, most likely
you will never need to touch them.
"""
APP_BASE_DIR = Path(os.path.dirname(os.path.realpath(__file__)))

LOG_FILE_DIR = APP_BASE_DIR / Path("logs")
