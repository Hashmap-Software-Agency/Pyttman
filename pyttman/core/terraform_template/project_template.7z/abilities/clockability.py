from datetime import datetime
from typing import Union
from pyttman.core.ability import Ability
from pyttman.core.intent import Intent
from pyttman.core.communication.models.containers import Reply, Message, ReplyStream
from pyttman.core.parsing import parsers
from pyttman.core.parsing.identifiers import DateTimeFormatIdentifier
from pyttman.core.parsing.parsers import EntityParserBase


class SetTimeFormat(Intent):
    """
    This intent allows users to set the format of 
    datetime strings. It uses the EntityParser API 
    with a DateTimeFormatIdentifier Identifier class 
    to do this efficiently and with very little code.
    """
    description = "Sets the format of datetime outputs"
    lead = ("set",)
    trail = ("datetime", "format",)
    example = "Set the datetime format to %m-%d-%y::%H:%M"

    class EntityParser(EntityParserBase):
        datetime_format = parsers.ValueParser(identifier=DateTimeFormatIdentifier)

    def respond(self, message: Message) -> Union[Reply, ReplyStream]:
        # Check the entities dict, populated by the EntityParser
        if datetime_format := self.entities.get("datetime_format"):

            # Accessing the Feature-scope Storage object
            self.storage.put("datetime_format", datetime_format)
            return Reply(f"Set datetime format to: {datetime_format}")
        else:
            return Reply("Hm, I didn't get which format you wanted to use?")


class GetTime(Intent):
    """
    This command returns a timestamp, with the 
    configured time format.
    """
    lead = ("what",)
    trail = ("time",)
    example = "What time is it?"

    def respond(self, message: Message) -> Union[Reply, ReplyStream]:
        time_format = self.storage.get("datetime_format")
        return Reply(f"The time is currently {datetime.now().strftime(time_format)}")


class ClockAbility(Ability):
    """
    A basic, simple ability which
    answers what time it is.
    """
    intents = (GetTime, SetTimeFormat)

    def configure(self):
        self.storage.put("datetime_format", "%y-%m-%d - %H:%M")
